package RHOP.testy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestyApplicationTests {

	@Test
	void contextLoads() {
	}

}
