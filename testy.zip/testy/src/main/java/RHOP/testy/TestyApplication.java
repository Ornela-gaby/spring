package RHOP.testy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestyApplication.class, args);
	}

}
